@echo off
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo Please run this file as Administrator ^(right click - Run as administrator^).
  pause & exit /b 1
)
set SVC=ReplicationMonitor
set EXE=%~dp0publish\ReplicationMonitor.exe
if not exist "%EXE%" (
  echo publish\ReplicationMonitor.exe not found. Run 1_Build.bat first.
  pause & exit /b 1
)
sc query %SVC% >nul 2>&1
if not errorlevel 1 (
  echo Existing service found - removing...
  sc stop %SVC% >nul 2>&1
  timeout /t 3 >nul
  sc delete %SVC% >nul 2>&1
  timeout /t 2 >nul
)
sc create %SVC% binPath= "\"%EXE%\"" start= auto DisplayName= "Replication Monitor"
sc description %SVC% "PostgreSQL replication monitor - web dashboard on port 5050"
sc failure %SVC% reset= 86400 actions= restart/5000/restart/5000/restart/5000
netsh advfirewall firewall delete rule name="ReplicationMonitor 5050" >nul 2>&1
netsh advfirewall firewall add rule name="ReplicationMonitor 5050" dir=in action=allow protocol=TCP localport=5050
sc start %SVC%
echo.
echo Service installed and started.
echo Dashboard:  http://localhost:5050
pause
