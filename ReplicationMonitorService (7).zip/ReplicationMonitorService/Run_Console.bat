@echo off
rem Test run without installing the service (Ctrl+C to stop)
cd /d "%~dp0publish"
echo Dashboard: http://localhost:5050
ReplicationMonitor.exe
pause
