# Called by 1_Build.bat - raises the patch number of the Service and Portal versions on every build.
# Edit version.json by hand to change the major/minor part (e.g. "1.1.0"); the last number is automatic.
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$vf   = Join-Path $root 'version.json'
if (Test-Path $vf) { $v = Get-Content $vf -Raw | ConvertFrom-Json }
else { $v = [pscustomobject]@{ service = '1.0.0'; portal = '1.0.0'; built = '' } }

function Bump([string]$s) {
    $p = @($s.Split('.'))
    while ($p.Count -lt 3) { $p += '0' }
    $p[2] = [string]([int]$p[2] + 1)
    return (($p[0], $p[1], $p[2]) -join '.')
}
$v.service = Bump $v.service
$v.portal  = Bump $v.portal
$now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$v | Add-Member -NotePropertyName built -NotePropertyValue $now -Force
$utf8 = New-Object System.Text.UTF8Encoding($false)

[IO.File]::WriteAllText($vf, ($v | ConvertTo-Json), $utf8)
[IO.File]::WriteAllText((Join-Path $root 'wwwroot\portal-version.json'),
    (([pscustomobject]@{ version = $v.portal; built = $now }) | ConvertTo-Json), $utf8)

$ix = Join-Path $root 'wwwroot\index.html'
$t  = [IO.File]::ReadAllText($ix, $utf8)
$t  = [regex]::Replace($t, "const PORTAL_VERSION = '[^']*';", "const PORTAL_VERSION = '$($v.portal)';")
[IO.File]::WriteAllText($ix, $t, $utf8)

Write-Output $v.service
